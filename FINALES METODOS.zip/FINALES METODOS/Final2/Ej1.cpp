#include <iostream>
#include <math.h>
#define FILAS 100
using namespace std;





	
void polinomica (double [FILAS][2], int fila);


void triangulacion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);
void retrostutitucion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);
void pivot(double a[FILAS][FILAS], double b[FILAS], int filas, int i);
double determinante(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);
	
	
	int main(int argc, char *argv[]) {
		/*double m[FILAS][2] = {{0,1},{60,4},{100,10}};//*/
		double a[FILAS][2] = {{0,1},{0.25,1.384},{0.5,1.849},{0.75,2.417},{1,3.118},{1.25,3.99},{1.5,5.082},{2,8.189}};
		int filas = 8; 
		polinomica(a,8);
	}
	
	void polinomica (double m[FILAS][2], int fila){
		double a[FILAS][FILAS]; 
		double b[FILAS];
		
		for (int i = 0; i < fila; i++) {
			for (int j = 0; j < fila +1 ; j++) {
				a[i][j] = pow(m[i][0], j);
			}
			b[i] = m[i][1];
		}
		printf("\nMatriz a\n");
		for (int i = 0; i < fila; i++) {
			for (int j = 0; j < fila; j++) {
				printf("%lf",a[i][j]);
				printf("\t");
			}
			printf("\n");
		}
		printf("\nMatriz b\n");
		for (int i = 0; i < fila; i++) {
			printf("%lf",b[i]);
			printf("\t");
		}
		
		double* x = (double*)malloc(fila * sizeof(double));
		triangulacion(a, b, x, fila);
		
	}
	void triangulacion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas){
		for (int i = 0 ; i < (filas - 1) ; i++){
			pivot(a, b, filas , i);
			for (int j = i + 1; j < filas; j++) {
				double factor = -a[j][i] / a[i][i];
				for (int k = 0; k < filas; ++k) {
					a[j][k] = a[i][k] * factor + a[j][k];
				}
				b[j] = b[i] * factor + b[j];
			}
		}
		
		double norma = determinante(a,b,x,filas);
		if(norma == 0.0){
			printf("\n\nmatriz singular");
		}else{
			retrostutitucion(a, b, x, filas);
		}
	}
	void retrostutitucion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas){
		double value = 0;
		value = b[filas - 1] / a[filas - 1][filas - 1];
		x[filas - 1] = value;
		for (int i = filas - 2; i >= 0; --i) {
			double sum = 0;
			for (int j = i + 1; j < filas; ++j) {
				sum = sum + a[i][j] * x[j];
			}
			value = (b[i] - sum) / a[i][i];
			x[i] = value;
		}
		printf("\n\n\n\nConjunto soluci?n de las asubn: \n");
		for (int i = 0; i < filas; ++i) {
			printf("a%d = %lf\n", i , x[i]);
		}
		
		printf("\n\n");
		printf("Polinomio Interpolador: \n");
		int pow = 0;
		for (int i = 0; i <= filas - 1; i++) {
			if (pow == 0)
				printf("%lf", x[i]);
			else {
				if (x[i] >= 0)
					printf(" + %lf.x^%d ", x[i], pow);
				else
					printf(" %lf.x^%d", x[i], pow);
			}
			pow++;
		}
}
	void pivot(double a[FILAS][FILAS], double b[FILAS], int filas, int i){
		if (fabs(a[i][i]) < 0.0001) {
			for (int j = i + 1; j < filas; j++) {
				if (fabs(a[j][i]) > fabs(a[i][i])) {
					for (int k = i; k < filas; ++k) {
						printf("Se realizo pivoteo\n");
						double swap = a[i][k];
						a[i][k] = a[j][k];
						a[j][k] = swap;
					}
					double swap = b[i];
					b[i] = b[j];
					b[j] = swap;
				}
			}
		}
	}
	double determinante(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas){
		double norma = 1;
		for(int i = 0; i < filas ; i++){
			norma = norma * a[i][i];
		}
		return norma;
	}
