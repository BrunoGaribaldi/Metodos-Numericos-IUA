#include <iostream>
#include <math.h> 
#include <stdlib.h>
#include <stdio.h>
#define FILAS 4
#define COLUMNAS 4
using namespace std;
void triangulacion(double a[FILAS][COLUMNAS], double b[FILAS], double x[FILAS], int filas);

//Funcion para retrostutituir matriz
void retrostutitucion(double a[FILAS][COLUMNAS], double b[FILAS], double x[FILAS], int filas);
void pivot(double a[FILAS][COLUMNAS], double b[FILAS], int filas, int i);
double determinante(double a[FILAS][COLUMNAS], double b[FILAS], double x[FILAS], int filas);
int main(int argc, char *argv[]) {
	double m[4][2] = {{0.5,-0.716},{0.8,-0.103},{1.3,3.419},{2.0,52.598}};
	double a[4][4] = {{0}};
	double b[4] = {0};
	int fila = 4;
//	for(int i = 0; i <4 ; i++){
//		a[0][0]+= pow(exp(m[i][0]*m[i][0]), 2);
//		a[0][1] += exp(m[i][0]*m[i][0]);
//		a[1][0] += exp(m[i][0]*m[i][0]);
//		a[1][1] = 4;
//		b[0] += m[i][1]*exp(m[i][0]*m[i][0]);
//		b[1] += m[i][1];
//	}
//	double* x = (double*)malloc(2 * sizeof(double));
//	triangulacion(a, b, x, 2);
	
	//a continuacion lagrange 
	
	for (int i = 0; i < fila; i++) {
		for (int j = 0; j < fila +1 ; j++) {
			a[i][j] = pow(m[i][0], j);
		}
		b[i] = m[i][1];
	}
	printf("\nMatriz a\n");
	for (int i = 0; i < fila; i++) {
		for (int j = 0; j < fila; j++) {
			printf("%lf",a[i][j]);
			printf("\t");
		}
		printf("\n");
	}
	printf("\nMatriz b\n");
	for (int i = 0; i < fila; i++) {
		printf("%lf",b[i]);
		printf("\t");
	}
	
	double* x = (double*)malloc(fila * sizeof(double));
	triangulacion(a, b, x, fila);
	return 0;
}
void triangulacion(double a[FILAS][COLUMNAS], double b[FILAS], double x[FILAS], int filas){
	for (int i = 0 ; i < (filas - 1) ; i++){
		pivot(a, b, filas , i);
		for (int j = i + 1; j < filas; j++) {
			double factor = -a[j][i] / a[i][i];
			for (int k = 0; k < filas; ++k) {
				a[j][k] = a[i][k] * factor + a[j][k];
			}
			b[j] = b[i] * factor + b[j];
		}
	}
	
	double norma = determinante(a,b,x,filas);
	if(norma == 0.0){
		printf("\n\nmatriz singular");
	}else{
		retrostutitucion(a, b, x, filas);
	}
}
	void retrostutitucion(double a[FILAS][COLUMNAS], double b[FILAS], double x[FILAS], int filas){
		double value = 0;
		value = b[filas - 1] / a[filas - 1][filas - 1];
		x[filas - 1] = value;
		for (int i = filas - 2; i >= 0; --i) {
			double sum = 0;
			for (int j = i + 1; j < filas; ++j) {
				sum = sum + a[i][j] * x[j];
			}
			value = (b[i] - sum) / a[i][i];
			x[i] = value;
		}
		printf("Conjunto solucion: \n");
		for (int i = 0; i < filas; ++i) {
			printf("x%d = %lf\n", i + 1, x[i]);
		}
	}
		void pivot(double a[FILAS][COLUMNAS], double b[FILAS], int filas, int i){
			if (fabs(a[i][i]) < 0.0001) {
				for (int j = i + 1; j < filas; j++) {
					if (fabs(a[j][i]) > fabs(a[i][i])) {
						for (int k = i; k < filas; ++k) {
							printf("Se realizo pivoteo\n");
							double swap = a[i][k];
							a[i][k] = a[j][k];
							a[j][k] = swap;
						}
						double swap = b[i];
						b[i] = b[j];
						b[j] = swap;
					}
				}
			}
		}
			double determinante(double a[FILAS][COLUMNAS], double b[FILAS], double x[FILAS], int filas){
				double norma = 1;
				for(int i = 0; i < filas ; i++){
					norma = norma * a[i][i];
				}
				printf("\nLa norma es: %lf\n",norma);
				return norma;
			}
