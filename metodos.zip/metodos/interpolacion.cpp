#include <iostream>
#include <math.h>
#define FILAS 20
using namespace std;


void fileReader (double m[FILAS][FILAS], int* filas, int* columnas);

void lagrange (double m[FILAS][FILAS], int fila);	
void polinomica (double [FILAS][FILAS], int fila);


double func (double x){
	
	return x + 2/x;
}


int main(int argc, char *argv[]) {
	
	double m[FILAS][FILAS];
	int filas = 0; 
	int columnas = 0; 
	int seleccion;
	fileReader(m,&filas, &columnas);
	printf("\ncantidad de filas %d, cantidad de columnas %d",filas,columnas);
	printf("\nIngrese:\n 1 --> Lagrange\n 2 --> Polinomica");
	scanf("%d",&seleccion);
	switch (seleccion){
		case 1: 
			lagrange(m, filas);
			break;
		case 2: 
			polinomica(m,filas);
			break;
		default: 
			printf("\nSe seleccion� mal la opcion");
			break;
	}

	return 0;
}
void fileReader (double m[FILAS][FILAS],int* filas, int* columnas){
	FILE *fp;
	char c;
	fp = fopen("data.txt","r");
	if ( fp == NULL )
	{
		printf("No se puede abrir el archivo");
	}
	int fila=0;
	int columna;
	while((c = fgetc(fp)) != EOF)
	{
		if(c == '\n'){
			fila++;
		}
	}
	
	fclose(fp);
	fp = fopen("data.txt","r");
	
	int i, j;
	for(i = 0; i < fila; i++) {
		j = 0;
		do {
			fscanf(fp, "%lf", &(m[i][j]));
			j++;
		} while((c = fgetc(fp)) != '\n');
	}
	columna = j;
	*columnas = columna;
	*filas = fila;
	
	for (int i = 0; i < fila; i++) {
		for (int j = 0; j < columna; j++) {
			printf("%lf",m[i][j]);
			printf("\t");
		}
		printf("\n");
	}
}
void lagrange (double m[FILAS][FILAS], int fila){
	double x;//Coeficiente a interpolar
	double e;
	printf("Recuerde haber definido la funcion previamente\n");
	printf("Ingrese el valor a interpolar\n");
	scanf("%lf", &x);
	
	double sum = 0; 
	for (int i = 0; i < fila; i++) {
		double producto = 1;
		for (int j = 0; j < fila; j++) {
			if (j != i) {
				producto *= ((x - m[i][0]) / (m[j][0] - m[i][0]));
			}
		}
		sum += m[i][1] * producto;
	}
	e = fabs(func(x) - sum);
	printf("El valor interpolado para %lf es: %lf, con un error de %lf", x, sum, e);
}
void polinomica (double m[FILAS][FILAS], int fila){
	double a[FILAS][FILAS]; 
	double b[FILAS];
	
	for (int i = 0; i < fila; i++) {
		for (int j = 0; j < fila +1 ; j++) {
			a[i][j] = pow(m[i][0], j);
		}
		b[i] = m[i][1];
	}
	printf("\nMatriz a\n");
	for (int i = 0; i < fila; i++) {
		for (int j = 0; j < fila; j++) {
			printf("%lf",a[i][j]);
			printf("\t");
		}
		printf("\n");
	}
	printf("\nMatriz b\n");
	for (int i = 0; i < fila; i++) {
		printf("%lf",b[i]);
		printf("\t");
	}
	
	
}
